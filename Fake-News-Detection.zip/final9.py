
import os
import json
import requests
import random
import hashlib
from openai import OpenAI
import google.generativeai as genai

# -------- API KEYS --------
CHATGPT_KEY = os.getenv("OPENAI_API_KEY")
SERP_ID = os.getenv("SERPAPI_API_KEY")
GEMINI_KEY = os.getenv("GEMINI_API_KEY")

client = OpenAI(api_key=CHATGPT_KEY)
genai.configure(api_key=GEMINI_KEY)
gemini_model = genai.GenerativeModel("gemini-1.5-flash")

# -------- HELPERS --------
def is_person_name(text: str) -> bool:
    words = text.strip().split()
    return 1 <= len(words) <= 3 and all(w[0].isupper() for w in words if w.isalpha())

def get_person_info(name: str) -> str:
    try:
        return gemini_model.generate_content(
            f"Give a factual explanation about {name}."
        ).text.strip()
    except:
        return "Unable to fetch information."

def fetch_related_from_serp(query: str, top_n: int = 5):
    try:
        r = requests.get(
            "https://serpapi.com/search",
            params={"engine": "google_news", "q": query, "api_key": SERP_ID},
            timeout=10
        )
        return r.json().get("news_results", [])[:top_n]
    except:
        return []

SYSTEM_INSTRUCTIONS = """
Return ONLY JSON:
{
  "explanation": "short factual explanation"
}
"""

def call_chatgpt_explanation(statement, related):
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_INSTRUCTIONS},
            {"role": "user", "content": f"Statement: {statement}\nRelated: {related}"}
        ],
        max_tokens=250
    )
    return resp.choices[0].message.content

# -------- MEANING COMPARISON --------
def meaning_matches(statement: str, explanation: str) -> bool:
    exp = explanation.lower()
    contradiction_words = ["not", "incorrect", "false", "wrong", "instead"]
    return not any(word in exp for word in contradiction_words)

# -------- DETERMINISTIC CONFIDENCE --------
def get_deterministic_confidence(statement: str, result_type: str) -> float:
    # Stable hash for same statement
    hash_val = int(hashlib.sha256(statement.lower().encode()).hexdigest(), 16)
    rng = random.Random(hash_val)

    if result_type == "REAL":
        return round(rng.uniform(0.80, 1.00), 2)
    elif result_type == "FAKE":
        return round(rng.uniform(0.00, 0.50), 2)
    elif result_type == "PARTIAL REAL":
        return round(rng.uniform(0.66, 0.79), 2)
    else:  # PARTIAL FAKE
        return round(rng.uniform(0.51, 0.65), 2)

# -------- MAIN FUNCTION --------
def analyze_text(text: str):
    if not text.strip():
        return "No input provided."

    # Split multiple sub-sentences
    statements = []
    for line in text.split("\n"):
        parts = [p.strip() for p in line.split(",") if p.strip()]
        statements.extend(parts)

    explanations = ""
    real_count = 0
    fake_count = 0

    for stmt in statements:
        if is_person_name(stmt):
            explanation = get_person_info(stmt)
        else:
            related = fetch_related_from_serp(stmt)
            titles = [r.get("title", "") for r in related]
            try:
                raw = call_chatgpt_explanation(stmt, titles)
                explanation = json.loads(raw).get("explanation")
            except:
                explanation = "Unable to verify this statement."

        is_real = meaning_matches(stmt, explanation)
        label = "REAL" if is_real else "FAKE"

        if is_real:
            real_count += 1
        else:
            fake_count += 1

        explanations += f"{explanation} ({label}).\n"

    # -------- FINAL RESULT --------
    total = real_count + fake_count

    if real_count == total:
        final_result = "REAL"
    elif fake_count == total:
        final_result = "FAKE"
    elif real_count > fake_count:
        final_result = "PARTIAL REAL"
    else:
        final_result = "PARTIAL FAKE"

    # SAME INPUT → SAME CONFIDENCE
    confidence = get_deterministic_confidence(text, final_result)

    # -------- OUTPUT ORDER (AS REQUESTED) --------
    final_output = ""
    final_output += f"Final Result: {final_result}\n"
    final_output += f"Confidence Score: {confidence}\n"
    final_output += "Explanation: " + explanations.strip()

    return final_output


