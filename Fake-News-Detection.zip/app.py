from flask import Flask, request, jsonify, render_template
from final9 import analyze_text
import webbrowser
from threading import Timer

app = Flask(__name__)

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    user_text = request.form.get("input_text", "")
    result = analyze_text(user_text)
    return jsonify({"result": result})

if __name__ == "__main__":
    Timer(1, open_browser).start()
    app.run(debug=True)
